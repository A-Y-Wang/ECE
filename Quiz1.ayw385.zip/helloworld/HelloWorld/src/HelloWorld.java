public class HelloWorld{
    public static void hello() {
        System.out.println("Hello World");
    }
}