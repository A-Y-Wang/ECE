package assignment1;

import static org.junit.Assert.*;

import org.junit.Test;
import org.junit.Rule;
import org.junit.rules.Timeout;

public class SortToolsTest {
    @Rule
    public Timeout globalTimeout = Timeout.seconds(2);

    // Write your JUnit tests here

    @Test
    public void test1() {
    }
}
