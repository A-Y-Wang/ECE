/*
 * SortTools.java dummy submission that passes 1 test case, and fails one.
 * Author: Vallath Nandakumar
 * June 2020
 */

package assignment1;
public class SortTools {

	// This function will pass sampleTest.
	// It will fail sampleTest1.
	public static int find(int [] arr, int n, int value) {
		return 2;
	}
}
